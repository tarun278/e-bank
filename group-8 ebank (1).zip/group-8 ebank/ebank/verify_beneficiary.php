<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_customer.php";
    include "connect.php";
    include "session_timeout.php";

    if (isset($_SESSION['auto_delete_benef'])) {
        if ($_SESSION['auto_delete_benef'] === true) {
            header("location:/auto_delete_beneficiary.php");
        }
    }

    if (isset($_SESSION['loggedIn_client_id'])) {
        $sql0 = "SELECT * FROM iiitv_bank_recipient".$_SESSION['loggedIn_client_id'];
    }

    $result = $conn->query($sql0);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $sql1 = "SELECT * FROM iiitv_bank_client WHERE
                                client_id=".$row["recipient_client_id"]." AND
                                client_email='".$row["client_email"]."' AND
                                client_phone='".$row["client_phone"]."' AND
                                client_account_no='".$row["client_account_no"]."'";

            $result1 = $conn->query($sql1);
            if ($result1->num_rows <= 0) {
                header("location:./delete_beneficiary.php?client_id=".$row["recipient_client_id"]."&redirect=true");
            }
        }
    }
?>
