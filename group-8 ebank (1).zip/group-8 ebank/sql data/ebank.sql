-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2021 at 05:25 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebank`
--

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_admin`
--

CREATE TABLE `iiitv_bank_admin` (
  `admin_id` int(10) NOT NULL,
  `admin_username` char(40) DEFAULT NULL,
  `admin_password` char(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_admin`
--

INSERT INTO `iiitv_bank_admin` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'bankserver', 'bankserver');

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_client`
--

CREATE TABLE `iiitv_bank_client` (
  `client_id` int(10) NOT NULL,
  `client_name` varchar(40) DEFAULT NULL,
  `client_surname` varchar(40) DEFAULT NULL,
  `client_gender` varchar(40) DEFAULT NULL,
  `client_date_of_birth` date DEFAULT NULL,
  `client_aadhar_id` int(10) DEFAULT NULL,
  `client_email` varchar(40) DEFAULT NULL,
  `client_phone` varchar(40) DEFAULT NULL,
  `client_registered_address` varchar(300) DEFAULT NULL,
  `client_city` varchar(40) DEFAULT NULL,
  `client_account_no` int(10) DEFAULT NULL,
  `client_identification` int(4) DEFAULT NULL,
  `client_username` varchar(40) DEFAULT NULL,
  `client_password` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_client`
--

INSERT INTO `iiitv_bank_client` (`client_id`, `client_name`, `client_surname`, `client_gender`, `client_date_of_birth`, `client_aadhar_id`, `client_email`, `client_phone`, `client_registered_address`, `client_city`, `client_account_no`, `client_identification`, `client_username`, `client_password`) VALUES
(1, 'Rohan', 'Chaudhary', 'male', '2000-09-02', 12345, 'Rohan@gmail.com', '+913855092907', 'Ss Iii/265, Sector 18, Kopar Khairne, Navi Mumbai', 'kathmandu', 107598, 1234, 'rohan', 'password'),
(2, 'Mohan', 'Acharya', 'male', '2000-12-28', 5555, 'Mohan@gmail.com', '+913850668468', 'Gold Seal House, Opp Ceat Tyres Ltd Village Road, Bhandup', 'Adilabad', 613592, 1235, 'mohan', 'password'),
(3, 'Soham', 'Agarwal', 'male', '2001-01-12', 11223344, 'Soham@gmail.com', '+913853482988', '6/2,rlyparallelrdkumarapkeast-1, Kumarapark East', 'Akola', 364471, 1236, 'soham', 'password'),
(4, 'Virat', 'Khatri', 'male', '2002-05-19', 1122345, 'Virat@gmail.com', '+913859376684', '1/a, Nehru Market, Behind R K Market, Kambliwadi, Vile Parle (east)', 'Allahabad', 590230, 1237, 'virat', 'password'),
(5, 'Rohit', 'Ahuja', 'male', '1970-05-01', 1123345, 'Rohit@gmail.com', '+913851419621', ' 22/4, Hosur Road Cross, Behind Vinayaka Templ, Madiwala', 'Alwar', 610748, 1238, 'rohit', 'password'),
(6, 'Sameer', 'Anand', 'male', '2001-05-10', 112345, 'Sameer@gmail.com', '+913852017839', 'Shop No 3, Sterling Apt, Pandit Dindayal Ngr, Vasai (west)', 'Ambedkar Nagar', 132878, 1239, 'sameer', 'password'),
(7, 'Rahul', 'Laghari', 'male', '2001-05-08', 124345, 'Rahul@gmail.com', '+913858414856', '136, Balani Niwas, Hkx Road No 2, Kandivali (west)', 'Amritsar', 122564, 1240, 'rahul', 'password'),
(8, 'Naman', 'Patel', 'male', '1970-05-13', 112345, 'Naman@gmail.com', '+913857209377', '7-8, Moti Cinema Compound, Chandni Chowk', 'Anuppur', 186415, 1241, 'naman', 'password'),
(9, 'Dwayne', 'Reddy', 'male', '1970-05-14', 123545, 'Dwayne@gmail.com', '+913852892257', '301,mint Street,2nd Floor, Vardhan Complex', 'Ashok Nagar', 576161, 1242, 'dwayne', 'password'),
(10, 'Ryan', 'Bakshi', 'male', '1970-05-18', 1123645, 'Ryan@gmail.com', '+913856775550', 'H-1, Part 1, South Extn', 'Balrampur', 291741, 1243, 'ryan', 'password'),
(11, 'Gaurav', 'Anthony', 'male', '2001-05-05', 1123475, 'Gaurav@gmail.com', '+913854200193', 'Altaf Nagar, Golibar Cross Road, Ghatkopar (west)', 'Bandipora', 205050, 1244, 'gaurav', 'password'),
(12, 'Ishika', 'Babu', 'female', '2001-05-03', 1123845, 'Ishika@gmail.com', '+913859933778', '5, Naviwadi ,.k.p Bldg, Dadiseth Agiary Lane, Chira Bazar', 'Bangalore Urban', 315170, 1245, 'ishika', 'password'),
(13, 'Aditi', 'Arya', 'female', '2001-05-07', 1123495, 'Aditi@gmail.com', '+913856023820', ' B 133 2nd Floor, Part 1', 'Baran', 791769, 1246, 'aditi', 'password'),
(14, 'Gauri', 'Balakrishnan', 'female', '1970-05-18', 1102345, 'Gauri@gmail.com', '+913857735530', '57, A L Market, Shalimar Bagh', 'Barnala', 774370, 1247, 'gauri', 'password'),
(15, 'Kartik', 'Banerjee', 'male', '2001-05-21', 1112345, 'Kartik@gmail.com', '+913856813730', 'J K Chambers First Floor, 77/83, Nagdevi Street', 'Darrang', 685175, 1248, 'kartik', 'password'),
(16, 'Reema', 'Burman', 'female', '2001-05-28', 1122345, 'Reema@gmail.com', '+913856847663', '3482/7, Hauz Qazi Chowk', 'Dausa', 953445, 1249, 'reema', 'password'),
(17, 'Seema', 'Bhatt', 'female', '2001-05-08', 1132345, 'Seema@gmail.com', '+913856952828', 'E 362, Dabua Colony, Faridabad', 'Dindori', 522048, 1250, 'seema', 'password'),
(18, 'Nupur', 'Basu', 'female', '1970-05-23', 1142345, 'Nupur@gmail.com', '+913853754120', 'E 18 Sector 23, Sanjay Colony', 'Dungapur', 578676, 1251, 'nupur', 'password'),
(19, 'Tanya', 'Bedi', 'female', '1970-05-24', 1152345, 'Tanya@gmail.com', '+913851024087', 'Plot No:229-6/77, Hasthinapuram', 'Dungapur', 891321, 1252, 'tanya', 'password'),
(20, 'Raveena', 'Varma', 'female', '2001-05-08', 1162345, 'Raveena@gmail.com', '+913855297096', 'Shop No 20, Bus Turnimal, Kalamboli, Navi Mumbai', 'East Champaran', 680188, 1253, 'raveena', 'password'),
(21, 'Riddhi', 'Chabra', 'female', '1970-05-17', 1172345, 'Riddhi@gmail.com', '+913854936148', 'Mandir Lane, Connaught Place', 'Fatehpur', 294774, 1254, 'riddhi', 'password'),
(22, 'Parth', 'Datta', 'male', '2001-05-19', 1182345, 'Parth@gmail.com', '+913853137963', '309, 201-201a, Itl Twin Tower, Netaji Subhash Chand Pl, Pitampura', 'Firozabad', 757595, 1255, 'parth', 'password'),
(23, 'Tanmay', 'Deshpande', 'male', '1970-05-01', 1192345, 'Tanmay@gmail.com', '+913856169584', '46, 3rd Floor, 19, Mani Bhavan, Pathak Wadi, Lohar Chawl', 'Ganderbal', 612075, 1256, 'tanmay', 'password'),
(24, 'Yuvraj', 'Mangal', 'male', '2001-05-02', 1202345, 'Yuvraj@gmail.com', '+913855028119', 'Kumkum Bldg Opp Lohana Boardin, Kumkum Bldg,opp Lohana Boarding, Raopura', 'Ganganagar', 741051, 1257, 'yuvraj', 'password'),
(25, 'Arohi', 'Joshi', 'female', '1970-05-03', 1212345, 'Arohi@gmail.com', '+913853963555', '13/3, Mathura Road', 'Haridwar', 336662, 1258, 'arohi', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_news`
--

CREATE TABLE `iiitv_bank_news` (
  `news_id` int(10) NOT NULL,
  `news_title` varchar(40) DEFAULT NULL,
  `news_publish_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_news`
--

INSERT INTO `iiitv_bank_news` (`news_id`, `news_title`, `news_publish_date`) VALUES
(0, 'dfg', '2021-04-24 20:47:08'),
(3, 'Piramal Housing to extend loans ', '2017-09-06 15:46:21'),
(4, 'ETFs', '2017-11-19 16:39:35'),
(5, 'LIC Paytm Partnership', '2019-09-27 21:07:12'),
(6, 'HDB Financial Services', '2019-09-28 13:35:58'),
(7, 'IEEE Gov-TechThon 2020', '2017-09-06 15:45:25'),
(8, 'Convocation', '2017-09-06 15:45:55'),
(9, 'SSIP Gujarat Industrial Hackathon', '2017-09-06 15:46:21'),
(10, 'DAIICT - SYNAPSE', '2017-11-19 16:39:35'),
(11, 'GAHSSR', '2019-09-03 21:07:12'),
(12, 'Institute of National Importance', '2019-09-17 13:35:58'),
(13, 'Indian Science Fiction Stories', '2019-09-18 17:15:27'),
(14, 'placement season', '2019-08-08 21:55:18');

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_news_body`
--

CREATE TABLE `iiitv_bank_news_body` (
  `news_id` int(10) NOT NULL,
  `news_body_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_news_body`
--

INSERT INTO `iiitv_bank_news_body` (`news_id`, `news_body_text`) VALUES
(0, 'gdsg'),
(3, 'Piramal Housing Finance that is shedding its overweight on builder loans is taking baby steps to become a financial conglomerate, a versatile retail lending platform that would lend to build small sized homes to buy a motorcycle leveraging on its recent tie ups with tech startups.'),
(4, 'Investors are turning to midcap, smallcap-focused ETFs'),
(5, 'LIC has appointed Paytm to facilitate digital payments. After tie-up with another payment gateway earlier, the insurance giant has sought a fresh contract as most of its payments shift to digital modes. The new contract requires a smoother payment process, wider variety of payment options and adding more players (banks, wallets, etc) in payment channels. '),
(6, 'HDB Financial Services (HDB) the non-banking finance company (NBFC) subsidiary of HDFC Bank reported a 17% drop in net profit in the quarter ended March 2021 due to higher provisions indicating the challenging economic environment facing the company which focuses on the risky unsecured personal loans, new to credit loans consumer durable loans, used car loans, credit card balance transfer and loans to small enterprises.'),
(7, 'IIIT Vadodara Team (Aman Raj, Aniket Dixit, Arpit Srivastava, and Ashutosh Singh ) Won 2nd prize in IEEE Gov-TechThon 2020 virtual Hackathon'),
(8, 'IIIT Vadodara held its 3rd Convocation on 07 Nov. 2020'),
(9, 'SSIP Gujarat Industrial Hackathon 2019 Grand Finale Result: \"3rd Position\" (Medium Scale Industry) Team: Dr. Kamal K. Jha (Mentor) Kshitij Palghane (Team Leader) Heet Sankesara (Member) Khilan Ravani (Member) Harshendra Shah (Member)'),
(10, 'ENCORE (Music Club) secured 1st position in Indian Group Song Competition at DAIICT - SYNAPSE 17'),
(11, 'Prof Barnali Chetia has been appointed as the honorary Chief Advisor of the scholarly association Global Association for Humanities and Social Science Research (GAHSSR)'),
(12, 'Indian Institute of Information Technology Vadodara declared as Institute of National Importance'),
(13, 'Flights of Imagination- A literary endeavour by budding writers of IIITV(Ayyar Meghna P, Kartik Sayani, Rahul Nalawade, Prateek Paliwal, Vaishnav Vishal, Krishnaunni Vadakkathyl, Diksha Chhabra, Kenneth Tenny, Parul Bindal, Akhil Sai Chikkala, Ajay Shewale, Bogadi Ranga Venkata Sai Prahlad published their short stories in Cradle Song- A Compendium of Indian Science Fiction Stories'),
(14, 'IIIT Vadodara placed 95% of its graduating students this placement season');

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient1`
--

CREATE TABLE `iiitv_bank_recipient1` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient1`
--

INSERT INTO `iiitv_bank_recipient1` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 2, 'Mohan@gmail.com', '+913850668468', 613592),
(2, 3, 'Soham@gmail.com', '+913853482988', 364471);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient2`
--

CREATE TABLE `iiitv_bank_recipient2` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient2`
--

INSERT INTO `iiitv_bank_recipient2` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 3, 'Soham@gmail.com', '+913853482988', 364471),
(2, 4, 'Virat@gmail.com', '+913859376684', 590230);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient3`
--

CREATE TABLE `iiitv_bank_recipient3` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient3`
--

INSERT INTO `iiitv_bank_recipient3` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 4, 'Virat@gmail.com', '+913859376684', 590230),
(2, 5, 'Rohit@gmail.com', '+913851419621', 6107483),
(3, 6, 'Sameer@gmail.com', '+913852017839', 132878);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient4`
--

CREATE TABLE `iiitv_bank_recipient4` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient4`
--

INSERT INTO `iiitv_bank_recipient4` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 5, 'Rohit@gmail.com', '+913851419621', 6107483),
(2, 6, 'Sameer@gmail.com', '+913852017839', 132878);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient5`
--

CREATE TABLE `iiitv_bank_recipient5` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient5`
--

INSERT INTO `iiitv_bank_recipient5` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 6, 'Sameer@gmail.com', '+913852017839', 132878),
(2, 7, 'Rahul@gmail.com', '+913858414856', 122564);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient6`
--

CREATE TABLE `iiitv_bank_recipient6` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient7`
--

CREATE TABLE `iiitv_bank_recipient7` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient7`
--

INSERT INTO `iiitv_bank_recipient7` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 8, 'Naman@gmail.com', '+913857209377', 186415);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient8`
--

CREATE TABLE `iiitv_bank_recipient8` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient8`
--

INSERT INTO `iiitv_bank_recipient8` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 9, 'Dwayne@gmail.com', '+913852892257', 576161),
(2, 10, 'Ryan@gmail.com', '+913856775550', 291741);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient9`
--

CREATE TABLE `iiitv_bank_recipient9` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient10`
--

CREATE TABLE `iiitv_bank_recipient10` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient10`
--

INSERT INTO `iiitv_bank_recipient10` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 11, 'Gaurav@gmail.com', '+913854200193', 205050),
(2, 12, 'Ishika@gmail.com', '+913859933778', 315170);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient11`
--

CREATE TABLE `iiitv_bank_recipient11` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient11`
--

INSERT INTO `iiitv_bank_recipient11` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 12, 'Ishika@gmail.com', '+913859933778', 315170),
(2, 13, 'Aditi@gmail.com', '+913856023820', 791769),
(3, 14, 'Gauri@gmail.com', '+913857735530', 774370);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient12`
--

CREATE TABLE `iiitv_bank_recipient12` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient12`
--

INSERT INTO `iiitv_bank_recipient12` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 13, 'Aditi@gmail.com', '+913856023820', 791769),
(2, 14, 'Gauri@gmail.com', '+913857735530', 774370);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient13`
--

CREATE TABLE `iiitv_bank_recipient13` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient13`
--

INSERT INTO `iiitv_bank_recipient13` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 14, 'Gauri@gmail.com', '+913857735530', 774370);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient14`
--

CREATE TABLE `iiitv_bank_recipient14` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient14`
--

INSERT INTO `iiitv_bank_recipient14` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 15, 'Kartik@gmail.com', '+913856813730', 685175),
(2, 16, 'Reema@gmail.com', '+913856847663', 953445);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient15`
--

CREATE TABLE `iiitv_bank_recipient15` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient15`
--

INSERT INTO `iiitv_bank_recipient15` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 16, 'Reema@gmail.com', '+913856847663', 953445),
(2, 17, 'Seema@gmail.com', '+913856952828', 522048),
(3, 19, 'Tanya@gmail.com', '+913851024087', 891321);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient16`
--

CREATE TABLE `iiitv_bank_recipient16` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient16`
--

INSERT INTO `iiitv_bank_recipient16` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 17, 'Seema@gmail.com', '+913856952828', 522048),
(2, 18, 'Nupur@gmail.com', '+913853754120', 578676);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient17`
--

CREATE TABLE `iiitv_bank_recipient17` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient18`
--

CREATE TABLE `iiitv_bank_recipient18` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient19`
--

CREATE TABLE `iiitv_bank_recipient19` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient19`
--

INSERT INTO `iiitv_bank_recipient19` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 20, 'Raveena@gmail.com', '+913855297096', 680188),
(2, 21, 'Riddhi@gmail.com', '+913854936148', 294774);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient20`
--

CREATE TABLE `iiitv_bank_recipient20` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient21`
--

CREATE TABLE `iiitv_bank_recipient21` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient21`
--

INSERT INTO `iiitv_bank_recipient21` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 22, 'Parth@gmail.com', '+913853137963', 757595),
(2, 23, 'Tanmay@gmail.com', '+913856169584', 612075);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient22`
--

CREATE TABLE `iiitv_bank_recipient22` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient22`
--

INSERT INTO `iiitv_bank_recipient22` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 23, 'Tanmay@gmail.com', '+913856169584', 612075);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient23`
--

CREATE TABLE `iiitv_bank_recipient23` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient23`
--

INSERT INTO `iiitv_bank_recipient23` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 24, 'Yuvraj@gmail.com', '+913855028119', 741051),
(2, 25, 'Arohi@gmail.com', '+913853963555', 336662);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient24`
--

CREATE TABLE `iiitv_bank_recipient24` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient24`
--

INSERT INTO `iiitv_bank_recipient24` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 1, 'Rohan@gmail.com', '+913855092907', 107598),
(2, 2, 'Mohan@gmail.com', '+913850668468', 613592);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_recipient25`
--

CREATE TABLE `iiitv_bank_recipient25` (
  `recipient_id` int(10) NOT NULL,
  `recipient_client_id` int(10) DEFAULT NULL,
  `recipient_email` varchar(40) DEFAULT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `recipient_acc_no` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_recipient25`
--

INSERT INTO `iiitv_bank_recipient25` (`recipient_id`, `recipient_client_id`, `recipient_email`, `recipient_phone`, `recipient_acc_no`) VALUES
(1, 8, 'Naman@gmail.com', '+913857209377', 186415),
(2, 9, 'Dwayne@gmail.com', '+913852892257', 576161),
(3, 10, 'Ryan@gmail.com', '+913856775550', 291741),
(4, 11, 'Gaurav@gmail.com', '+913854200193', 205050);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record1`
--

CREATE TABLE `iiitv_bank_record1` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record1`
--

INSERT INTO `iiitv_bank_record1` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 3883036, 3883036),
(2, '2021-03-23 22:41:22', 'Debited Money transferred to a/c number 613592', 0, 150000, 3733036),
(3, '2021-04-02 19:50:49', 'Debited Money transferred to a/c number 364471', 0, 150000, 3583036),
(4, '2021-02-16 15:14:11', 'Credited Money transferred by a/c number 741051', 150000, 0, 3733036);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record2`
--

CREATE TABLE `iiitv_bank_record2` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record2`
--

INSERT INTO `iiitv_bank_record2` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 1102023, 1102023),
(2, '2021-03-13 15:37:45', 'Debited Money transferred to a/c number 364471', 0, 150000, 952023),
(3, '2021-03-22 04:04:30', 'Debited Money transferred to a/c number 590230', 0, 150000, 802023),
(4, '2021-03-23 22:41:22', 'Credited Money transferred by a/c number 107598', 150000, 0, 952023),
(5, '2021-03-09 19:10:44', 'Credited Money transferred by a/c number 741051', 150000, 0, 1102023);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record3`
--

CREATE TABLE `iiitv_bank_record3` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record3`
--

INSERT INTO `iiitv_bank_record3` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 4404692, 4404692),
(2, '2021-03-27 23:59:29', 'Debited Money transferred to a/c number 590230', 0, 150000, 4254692),
(3, '2021-03-17 23:28:55', 'Debited Money transferred to a/c number 610748', 0, 150000, 4104692),
(4, '2021-03-02 22:04:16', 'Debited Money transferred to a/c number 132878', 0, 150000, 3954692),
(5, '2021-04-02 19:50:49', 'Credited Money transferred by a/c number 107598', 150000, 0, 4104692),
(6, '2021-03-13 15:37:45', 'Credited Money transferred by a/c number 613592', 150000, 0, 4254692);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record4`
--

CREATE TABLE `iiitv_bank_record4` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record4`
--

INSERT INTO `iiitv_bank_record4` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 9985640, 9985640),
(2, '2021-03-27 15:51:50', 'Debited Money transferred to a/c number 610748', 0, 150000, 9835640),
(3, '2021-03-13 20:16:04', 'Debited Money transferred to a/c number 132878', 0, 150000, 9685640),
(4, '2021-03-22 04:04:30', 'Credited Money transferred by a/c number 613592', 150000, 0, 9835640),
(5, '2021-03-27 23:59:29', 'Credited Money transferred by a/c number 364471', 150000, 0, 9985640);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record5`
--

CREATE TABLE `iiitv_bank_record5` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record5`
--

INSERT INTO `iiitv_bank_record5` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 3649183, 3649183),
(2, '2021-02-23 10:51:42', 'Debited Money transferred to a/c number 132878', 0, 150000, 3499183),
(3, '2021-03-03 13:18:23', 'Debited Money transferred to a/c number 122564', 0, 150000, 3349183),
(4, '2021-03-17 23:28:55', 'Credited Money transferred by a/c number 364471', 150000, 0, 3499183),
(5, '2021-03-27 15:51:50', 'Credited Money transferred by a/c number 590230', 150000, 0, 3649183);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record6`
--

CREATE TABLE `iiitv_bank_record6` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record6`
--

INSERT INTO `iiitv_bank_record6` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 5851532, 5851532),
(2, '2021-03-02 22:04:16', 'Credited Money transferred by a/c number 364471', 150000, 0, 6001532),
(3, '2021-03-13 20:16:04', 'Credited Money transferred by a/c number 590230', 150000, 0, 6151532),
(4, '2021-02-23 10:51:42', 'Credited Money transferred by a/c number 610748', 150000, 0, 6301532);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record7`
--

CREATE TABLE `iiitv_bank_record7` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record7`
--

INSERT INTO `iiitv_bank_record7` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 1062418, 1062418),
(2, '2021-03-26 10:53:21', 'Debited Money transferred to a/c number 186415', 0, 150000, 912418),
(3, '2021-03-03 13:18:23', 'Credited Money transferred by a/c number 610748', 150000, 0, 1062418);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record8`
--

CREATE TABLE `iiitv_bank_record8` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record8`
--

INSERT INTO `iiitv_bank_record8` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 8124546, 8124546),
(2, '2021-04-08 14:39:16', 'Debited Money transferred to a/c number 576161', 0, 150000, 7974546),
(3, '2021-02-20 03:07:52', 'Debited Money transferred to a/c number 291741', 0, 150000, 7824546),
(4, '2021-03-26 10:53:21', 'Credited Money transferred by a/c number 122564', 150000, 0, 7974546),
(5, '2021-04-08 01:58:49', 'Credited Money transferred by a/c number 336662', 150000, 0, 8124546);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record9`
--

CREATE TABLE `iiitv_bank_record9` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record9`
--

INSERT INTO `iiitv_bank_record9` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 1537097, 1537097),
(2, '2021-04-08 14:39:16', 'Credited Money transferred by a/c number 186415', 150000, 0, 1687097),
(3, '2021-02-24 20:02:38', 'Credited Money transferred by a/c number 336662', 150000, 0, 1837097);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record10`
--

CREATE TABLE `iiitv_bank_record10` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record10`
--

INSERT INTO `iiitv_bank_record10` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 5376969, 5376969),
(2, '2021-02-20 18:28:41', 'Debited Money transferred to a/c number 205050', 0, 150000, 5226969),
(3, '2021-03-07 01:25:37', 'Debited Money transferred to a/c number 315170', 0, 150000, 5076969),
(4, '2021-02-20 03:07:52', 'Credited Money transferred by a/c number 186415', 150000, 0, 5226969),
(5, '2021-03-16 10:21:38', 'Credited Money transferred by a/c number 336662', 150000, 0, 5376969);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record11`
--

CREATE TABLE `iiitv_bank_record11` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record11`
--

INSERT INTO `iiitv_bank_record11` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 8481792, 8481792),
(2, '2021-03-16 00:14:25', 'Debited Money transferred to a/c number 315170', 0, 150000, 8331792),
(3, '2021-03-27 01:45:48', 'Debited Money transferred to a/c number 791769', 0, 150000, 8181792),
(4, '2021-03-09 00:34:21', 'Debited Money transferred to a/c number 774370', 0, 150000, 8031792),
(5, '2021-02-20 18:28:41', 'Credited Money transferred by a/c number 291741', 150000, 0, 8181792),
(6, '2021-02-28 06:01:18', 'Credited Money transferred by a/c number 336662', 150000, 0, 8331792);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record12`
--

CREATE TABLE `iiitv_bank_record12` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record12`
--

INSERT INTO `iiitv_bank_record12` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 4145870, 4145870),
(2, '2021-03-07 01:08:02', 'Debited Money transferred to a/c number 791769', 0, 150000, 3995870),
(3, '2021-03-30 13:31:05', 'Debited Money transferred to a/c number 774370', 0, 150000, 3845870),
(4, '2021-03-07 01:25:37', 'Credited Money transferred by a/c number 291741', 150000, 0, 3995870),
(5, '2021-03-16 00:14:25', 'Credited Money transferred by a/c number 205050', 150000, 0, 4145870);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record13`
--

CREATE TABLE `iiitv_bank_record13` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record13`
--

INSERT INTO `iiitv_bank_record13` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 1251477, 1251477),
(2, '2021-02-15 21:39:54', 'Debited Money transferred to a/c number 774370', 0, 150000, 1101477),
(3, '2021-03-27 01:45:48', 'Credited Money transferred by a/c number 205050', 150000, 0, 1251477),
(4, '2021-03-07 01:08:02', 'Credited Money transferred by a/c number 315170', 150000, 0, 1401477);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record14`
--

CREATE TABLE `iiitv_bank_record14` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record14`
--

INSERT INTO `iiitv_bank_record14` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 2619292, 2619292),
(2, '2021-02-22 00:33:22', 'Debited Money transferred to a/c number 685175', 0, 150000, 2469292),
(3, '2021-03-14 16:50:59', 'Debited Money transferred to a/c number 953445', 0, 150000, 2319292),
(4, '2021-03-09 00:34:21', 'Credited Money transferred by a/c number 205050', 150000, 0, 2469292),
(5, '2021-03-30 13:31:05', 'Credited Money transferred by a/c number 315170', 150000, 0, 2619292),
(6, '2021-03-23 22:41:22', 'Credited Money transferred by a/c number 791769', 150000, 0, 2769292);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record15`
--

CREATE TABLE `iiitv_bank_record15` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record15`
--

INSERT INTO `iiitv_bank_record15` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 5452775, 5452775),
(2, '2021-02-24 10:38:33', 'Debited Money transferred to a/c number 953445', 0, 150000, 5302775),
(3, '2021-03-05 20:45:06', 'Debited Money transferred to a/c number 522048', 0, 150000, 5152775),
(4, '2021-03-15 05:42:12', 'Debited Money transferred to a/c number 891321', 0, 150000, 5002775),
(5, '2021-02-22 00:33:22', 'Credited Money transferred by a/c number 774370', 150000, 0, 5152775);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record16`
--

CREATE TABLE `iiitv_bank_record16` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record16`
--

INSERT INTO `iiitv_bank_record16` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 6185533, 6185533),
(2, '2021-02-17 11:14:03', 'Debited Money transferred to a/c number 522048', 0, 150000, 6035533),
(3, '2021-03-24 18:26:50', 'Debited Money transferred to a/c number 578676', 0, 150000, 5885533),
(4, '2021-03-14 16:50:59', 'Credited Money transferred by a/c number 774370', 150000, 0, 6035533),
(5, '2021-02-24 10:38:33', 'Credited Money transferred by a/c number 685175', 150000, 0, 6185533);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record17`
--

CREATE TABLE `iiitv_bank_record17` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record17`
--

INSERT INTO `iiitv_bank_record17` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 7620612, 7620612),
(2, '2021-03-05 20:45:06', 'Credited Money transferred by a/c number 685175', 150000, 0, 7770612),
(3, '2021-02-17 11:14:03', 'Credited Money transferred by a/c number 953445', 150000, 0, 7920612);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record18`
--

CREATE TABLE `iiitv_bank_record18` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record18`
--

INSERT INTO `iiitv_bank_record18` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 3300221, 3300221),
(2, '2021-03-24 18:26:50', 'Credited Money transferred by a/c number 953445', 150000, 0, 3450221);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record19`
--

CREATE TABLE `iiitv_bank_record19` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record19`
--

INSERT INTO `iiitv_bank_record19` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 5318321, 5318321),
(2, '2021-03-11 21:56:11', 'Debited Money transferred to a/c number 680188', 0, 150000, 5168321),
(3, '2021-02-23 13:29:09', 'Debited Money transferred to a/c number 294774', 0, 150000, 5018321),
(4, '2021-03-15 05:42:12', 'Credited Money transferred by a/c number 685175', 150000, 0, 5168321);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record20`
--

CREATE TABLE `iiitv_bank_record20` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record20`
--

INSERT INTO `iiitv_bank_record20` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 1367197, 1367197),
(2, '2021-03-11 21:56:11', 'Credited Money transferred by a/c number 891321', 150000, 0, 1517197);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record21`
--

CREATE TABLE `iiitv_bank_record21` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record21`
--

INSERT INTO `iiitv_bank_record21` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 5593853, 5593853),
(2, '2021-02-18 20:49:03', 'Debited Money transferred to a/c number 757595', 0, 150000, 5443853),
(3, '2021-04-15 23:06:10', 'Debited Money transferred to a/c number 612075', 0, 150000, 5293853),
(4, '2021-02-23 13:29:09', 'Credited Money transferred by a/c number 891321', 150000, 0, 5443853);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record22`
--

CREATE TABLE `iiitv_bank_record22` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iiitv_bank_record22`
--

INSERT INTO `iiitv_bank_record22` (`transaction_id`, `transaction_date`, `transaction_comments`, `transaction_debit`, `transaction_credit`, `net_balance`) VALUES
(1, '2021-01-01 00:00:01', 'Initial Deposit', 0, 4163752, 4163752),
(2, '2021-04-12 10:57:38', 'Debited Money transferred to a/c number 612075', 0, 150000, 4013752),
(3, '2021-02-18 20:49:03', 'Credited Money transferred by a/c number 294774', 150000, 0, 4163752);

-- --------------------------------------------------------

--
-- Table structure for table `iiitv_bank_record23`
--

CREATE TABLE `iiitv_bank_record23` (
  `transaction_id` int(10) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `transaction_comments` text DEFAULT NULL,
  `transaction_debit` int(10) DEFAULT NULL,
  `transaction_credit` int(10) DEFAULT NULL,
  `net_balance` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `iiitv_bank_admin`
--
ALTER TABLE `iiitv_bank_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `iiitv_bank_client`
--
ALTER TABLE `iiitv_bank_client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `iiitv_bank_news`
--
ALTER TABLE `iiitv_bank_news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `iiitv_bank_news_body`
--
ALTER TABLE `iiitv_bank_news_body`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `iiitv_bank_recipient1`
--
ALTER TABLE `iiitv_bank_recipient1`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient2`
--
ALTER TABLE `iiitv_bank_recipient2`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient3`
--
ALTER TABLE `iiitv_bank_recipient3`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient4`
--
ALTER TABLE `iiitv_bank_recipient4`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient5`
--
ALTER TABLE `iiitv_bank_recipient5`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient6`
--
ALTER TABLE `iiitv_bank_recipient6`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient7`
--
ALTER TABLE `iiitv_bank_recipient7`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient8`
--
ALTER TABLE `iiitv_bank_recipient8`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient9`
--
ALTER TABLE `iiitv_bank_recipient9`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient10`
--
ALTER TABLE `iiitv_bank_recipient10`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient11`
--
ALTER TABLE `iiitv_bank_recipient11`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient12`
--
ALTER TABLE `iiitv_bank_recipient12`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient13`
--
ALTER TABLE `iiitv_bank_recipient13`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient14`
--
ALTER TABLE `iiitv_bank_recipient14`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient15`
--
ALTER TABLE `iiitv_bank_recipient15`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient16`
--
ALTER TABLE `iiitv_bank_recipient16`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient17`
--
ALTER TABLE `iiitv_bank_recipient17`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient18`
--
ALTER TABLE `iiitv_bank_recipient18`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient19`
--
ALTER TABLE `iiitv_bank_recipient19`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient20`
--
ALTER TABLE `iiitv_bank_recipient20`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient21`
--
ALTER TABLE `iiitv_bank_recipient21`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient22`
--
ALTER TABLE `iiitv_bank_recipient22`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient23`
--
ALTER TABLE `iiitv_bank_recipient23`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient24`
--
ALTER TABLE `iiitv_bank_recipient24`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_recipient25`
--
ALTER TABLE `iiitv_bank_recipient25`
  ADD PRIMARY KEY (`recipient_id`);

--
-- Indexes for table `iiitv_bank_record1`
--
ALTER TABLE `iiitv_bank_record1`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record2`
--
ALTER TABLE `iiitv_bank_record2`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record3`
--
ALTER TABLE `iiitv_bank_record3`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record4`
--
ALTER TABLE `iiitv_bank_record4`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record5`
--
ALTER TABLE `iiitv_bank_record5`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record6`
--
ALTER TABLE `iiitv_bank_record6`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record7`
--
ALTER TABLE `iiitv_bank_record7`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record8`
--
ALTER TABLE `iiitv_bank_record8`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record9`
--
ALTER TABLE `iiitv_bank_record9`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record10`
--
ALTER TABLE `iiitv_bank_record10`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record11`
--
ALTER TABLE `iiitv_bank_record11`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record12`
--
ALTER TABLE `iiitv_bank_record12`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record13`
--
ALTER TABLE `iiitv_bank_record13`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record14`
--
ALTER TABLE `iiitv_bank_record14`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record15`
--
ALTER TABLE `iiitv_bank_record15`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record16`
--
ALTER TABLE `iiitv_bank_record16`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record17`
--
ALTER TABLE `iiitv_bank_record17`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record18`
--
ALTER TABLE `iiitv_bank_record18`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record19`
--
ALTER TABLE `iiitv_bank_record19`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record20`
--
ALTER TABLE `iiitv_bank_record20`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record21`
--
ALTER TABLE `iiitv_bank_record21`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record22`
--
ALTER TABLE `iiitv_bank_record22`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `iiitv_bank_record23`
--
ALTER TABLE `iiitv_bank_record23`
  ADD PRIMARY KEY (`transaction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
